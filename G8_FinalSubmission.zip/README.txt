To run the code:
1. Upload the given files onto Colab to ensure all the required libraries are available. 
2. Run command !sh data_downloader.sh to download the datasets.
3. Run command !python train_Unet_v2.py to start the training of the model. 
4. Model is stored in /model.
5. Run command !vis.py to run testing script and get an output of the scan, ground truth mask and predicted mask.